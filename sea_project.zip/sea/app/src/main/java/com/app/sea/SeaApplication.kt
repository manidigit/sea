package com.app.sea

import android.app.Application
import dagger.hilt.android.HiltAndroidApp

@HiltAndroidApp
class SeaApplication : Application()