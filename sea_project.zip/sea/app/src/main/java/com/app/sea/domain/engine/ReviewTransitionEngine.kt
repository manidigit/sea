package com.app.sea.domain.engine

import java.time.Instant
import java.time.temporal.ChronoUnit

enum class ReviewStage { DAILY, WEEKLY, MONTHLY, LEARNED }
enum class Difficulty { EASY, MEDIUM, HARD, VERY_HARD }
enum class ReviewAnswer { CORRECT, INCORRECT }

data class LearningStateDomain(
    val conceptId: Long,
    val stage: ReviewStage,
    val difficulty: Difficulty,
    val nextReviewAt: Long?,
    val monthlyWrongCount: Int,
    val totalCorrect: Int,
    val totalWrong: Int,
    val lastReviewedAt: Long?
)

data class TransitionResult(
    val updatedState: LearningStateDomain,
    val previousStage: ReviewStage,
    val newStage: ReviewStage,
    val previousDifficulty: Difficulty,
    val newDifficulty: Difficulty
)

object ReviewTransitionEngine {

    fun calculateTransition(
        currentState: LearningStateDomain,
        answer: ReviewAnswer,
        now: Instant,
        isFirstTimeFullPass: Boolean = false
    ): TransitionResult {
        val nowMillis = now.toEpochMilli()

        var newStage = currentState.stage
        var newDifficulty = currentState.difficulty
        var newNextReviewAt: Long? = currentState.nextReviewAt
        var newMonthlyWrongCount = currentState.monthlyWrongCount
        var newTotalCorrect = currentState.totalCorrect
        var newTotalWrong = currentState.totalWrong

        when (answer) {
            ReviewAnswer.CORRECT -> {
                newTotalCorrect += 1
                when (currentState.stage) {
                    ReviewStage.DAILY -> {
                        newStage = ReviewStage.WEEKLY
                        newNextReviewAt = now.plus(7, ChronoUnit.DAYS).toEpochMilli()
                    }
                    ReviewStage.WEEKLY -> {
                        newStage = ReviewStage.MONTHLY
                        newNextReviewAt = now.plus(30, ChronoUnit.DAYS).toEpochMilli()
                    }
                    ReviewStage.MONTHLY -> {
                        newStage = ReviewStage.LEARNED
                        newNextReviewAt = null
                        if (isFirstTimeFullPass) {
                            newDifficulty = Difficulty.EASY
                        }
                    }
                    ReviewStage.LEARNED -> {
                        newNextReviewAt = null
                    }
                }
            }
            ReviewAnswer.INCORRECT -> {
                newTotalWrong += 1
                when (currentState.stage) {
                    ReviewStage.DAILY -> {
                        newStage = ReviewStage.DAILY
                        newNextReviewAt = nowMillis
                    }
                    ReviewStage.WEEKLY -> {
                        newStage = ReviewStage.DAILY
                        newNextReviewAt = nowMillis
                        if (currentState.difficulty == Difficulty.EASY) {
                            newDifficulty = Difficulty.MEDIUM
                        }
                    }
                    ReviewStage.MONTHLY -> {
                        newStage = ReviewStage.DAILY
                        newNextReviewAt = nowMillis
                        newMonthlyWrongCount += 1
                        newDifficulty = if (newMonthlyWrongCount > 1) {
                            Difficulty.VERY_HARD
                        } else {
                            Difficulty.HARD
                        }
                    }
                    ReviewStage.LEARNED -> {
                        newNextReviewAt = null
                    }
                }
            }
        }

        val updatedState = currentState.copy(
            stage = newStage,
            difficulty = newDifficulty,
            nextReviewAt = newNextReviewAt,
            monthlyWrongCount = newMonthlyWrongCount,
            totalCorrect = newTotalCorrect,
            totalWrong = newTotalWrong,
            lastReviewedAt = nowMillis
        )

        return TransitionResult(
            updatedState = updatedState,
            previousStage = currentState.stage,
            newStage = newStage,
            previousDifficulty = currentState.difficulty,
            newDifficulty = newDifficulty
        )
    }
}