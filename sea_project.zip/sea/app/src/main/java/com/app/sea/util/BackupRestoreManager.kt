package com.app.sea.util

import android.content.Context
import com.app.sea.database.SeaDatabase
import dagger.hilt.android.qualifiers.ApplicationContext
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class BackupRestoreManager @Inject constructor(
    @ApplicationContext private val context: Context,
    private val database: SeaDatabase
) {
    private val dbName = "sea_database.db"

    fun exportDatabase(destFile: File): Result<Unit> = runCatching {
        database.openHelper.writableDatabase.query("PRAGMA checkpoint_full;").close()
        val currentDbFile = context.getDatabasePath(dbName)
        if (!currentDbFile.exists()) throw IllegalStateException("Database file not found.")

        FileInputStream(currentDbFile).use { input ->
            FileOutputStream(destFile).use { output ->
                input.copyTo(output)
            }
        }
    }

    fun restoreDatabase(sourceFile: File): Result<Unit> = runCatching {
        database.close()
        val currentDbFile = context.getDatabasePath(dbName)
        FileInputStream(sourceFile).use { input ->
            FileOutputStream(currentDbFile).use { output ->
                input.copyTo(output)
            }
        }
    }
}